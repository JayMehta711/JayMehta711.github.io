//
//  ViewController.swift
//  ReferenceJourneyApp
//
//  Created by Jay Mehta on 26/03/21.
//

import UIKit
import ReferenceJourney

enum Environment {
    static let fileMock = "FILE MOCK"
    static let cert = "CERT"
}

class EntityEnvironmentViewController: UIViewController, ThemeReacting {
    
    
    
    private var pickerMap: [String: [String]]! = [:]
    let appEnvList = [Environment.fileMock, Environment.cert]
    let appEntityList = ["IN","USA","UAE"]
    var userlist: [String] = []
    var presenter: ReferenceJourneyAppLauncherPreseterInterface?
    
    //Views
    private let scrollView = UIScrollView()
    private let containerView = UIView()
    private var entityPicker = UIPickerView()
    private var envPicker = UIPickerView()
    private var userPicker = UIPickerView()
    private let continueBtn = UIButton()
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        setConfig()
        setNavigationBar()
        setupView()
        setUpLayout()
        
        ThemeManager.shared.addReactor(self)
    }
    
    func themeDidChange(_ theme: Theme) {
        self.view.backgroundColor = ThemeManager.shared.currentTheme.colors.backgroundHiglighted
        continueBtn.backgroundColor = ThemeManager.shared.currentTheme.colors.primaryButton
    }
   

    private func setNavigationBar() {
        navigationItem.title = "Test Harness Page"
        navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: .plain, target: nil, action: nil)
        let themeBarButton = UIBarButtonItem(title: "Theme", style: .plain, target: self, action: #selector(themeSelection))
        navigationItem.rightBarButtonItem = themeBarButton
    }
    
    private func setConfig() {
        
        let presenter = ReferenceJourneyAppLancherPresenter()
        let router = ReferenceJourneyAppRouter()
        let interector = ReferenceJourneyAppLauncherInteractor()
        interector.presenter = presenter
        presenter.router = router
        presenter.interector = interector
        self.setPresenter(presenter: presenter)
        router.viewController = self
    }
    
    private func setupView() {
        self.view.backgroundColor = ThemeManager.shared.currentTheme.colors.backgroundHiglighted
        containerView.translatesAutoresizingMaskIntoConstraints = false
        scrollView.translatesAutoresizingMaskIntoConstraints = false
        scrollView.alwaysBounceVertical = true
        containerView.backgroundColor = .white
        scrollView.backgroundColor = .white
        view.addSubview(scrollView)
        scrollView.addSubview(containerView)
    }
    
    private func setUpLayout() {
        //Entity Label
        let entityPickerLabel = populateLabel(text: "Select Entity", relativeTo: containerView.topAnchor, space: 30)
        
        //Enity Picker
        entityPicker = populatePicker(picker: entityPicker, accessibilityIdentifier: "entityPicker", relativeTo: entityPickerLabel.bottomAnchor)
        
        pickerMap[entityPicker.accessibilityIdentifier!] = appEntityList
        
        //Environment Label
        let envPickerlabel = populateLabel(text: "Select Environment", relativeTo: entityPicker.bottomAnchor,
                                           space: 20)
        //Env Picker
        envPicker = populatePicker(picker: envPicker, accessibilityIdentifier: "envPicker", relativeTo:    envPickerlabel.bottomAnchor)
        pickerMap[envPicker.accessibilityIdentifier!] = appEnvList
        
        //Select User Label || Scenario
        let userPickerLabel = populateLabel(text: "Select User", relativeTo: envPicker.bottomAnchor, space: 20)
        
        //User Picker || Scenario Picker
        let userPickerData = [String]()
        pickerMap["userPicker"] = userPickerData
        userPicker = populatePicker(picker: userPicker, accessibilityIdentifier: "userPicker", relativeTo: userPickerLabel.bottomAnchor)
        
        continueBtn.translatesAutoresizingMaskIntoConstraints = false
        continueBtn.backgroundColor = ThemeManager.shared.currentTheme.colors.primaryButton
        continueBtn.setTitle("Continue", for: .normal)
        continueBtn.accessibilityIdentifier = "continueButton"
        continueBtn.addTarget(self, action: #selector(continueButtonAction), for: .touchUpInside)
        containerView.addSubview(continueBtn)
        
        NSLayoutConstraint.activate([
            scrollView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            scrollView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            scrollView.topAnchor.constraint(equalTo: view.topAnchor),
            scrollView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            
            containerView.leadingAnchor.constraint(equalTo: scrollView.safeAreaLayoutGuide.leadingAnchor),
            containerView.trailingAnchor.constraint(equalTo: scrollView.safeAreaLayoutGuide.trailingAnchor),
            containerView.topAnchor.constraint(greaterThanOrEqualTo: scrollView.topAnchor),
            containerView.bottomAnchor.constraint(equalTo: scrollView.bottomAnchor),
            
            continueBtn.topAnchor.constraint(equalTo: userPicker.bottomAnchor, constant: 20),
            continueBtn.heightAnchor.constraint(equalToConstant: 44),
            continueBtn.leadingAnchor.constraint(equalTo: containerView.leadingAnchor, constant: 30),
            continueBtn.trailingAnchor.constraint(equalTo: containerView.trailingAnchor, constant: -30),
            continueBtn.bottomAnchor.constraint(equalTo: containerView.bottomAnchor, constant: -30)
        ])
    }
    
    func setPresenter(presenter: ReferenceJourneyAppLauncherPreseterInterface) {
        self.presenter = presenter
    }
    
    @objc func continueButtonAction() {
        let selecetedEntity = retrivePickerValue(entityPicker)
        let selectedEnv = retrivePickerValue(envPicker)
        //let selectedUser = retrivePickerValue(userPicker)
        
        presenter?.presentLaunchScreen(withSelectedEntity: selecetedEntity,
                                      withSelectedEnv: selectedEnv)
    }
    
    @objc func themeSelection() {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
        let themeSelector = appDelegate.themeSelector
        let sheet = UIAlertController(title: "ADL Themes",
                                      message: nil,
                                      preferredStyle: .actionSheet)
        Theme.Brand.allCases.forEach { brand in
            let action = UIAlertAction(title: brand.userReadableName, style: .default, handler: { _ in
                themeSelector.currentBrand = brand
            })
            action.isEnabled = (brand != themeSelector.currentBrand)
            sheet.addAction(action)
        }
        
        let cancel = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
        sheet.addAction(cancel)
        present(sheet, animated: true, completion: nil)
    }
    
    private func populateLabel(text: String,
                               relativeTo: NSLayoutYAxisAnchor,
                               space: CGFloat) -> UILabel {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.attributedText = NSAttributedString(string: text, attributes: [.underlineStyle: NSUnderlineStyle.single.rawValue])
        label.textColor = UIColor.blue
        label.font = UIFont.boldSystemFont(ofSize: 20)
        containerView.addSubview(label)
        NSLayoutConstraint.activate([
            label.centerXAnchor.constraint(equalTo: self.containerView.centerXAnchor),
            label.heightAnchor.constraint(equalToConstant: 20),
            label.topAnchor.constraint(equalTo: relativeTo, constant:  space)
        ])
        
        return label
    }
    
    private func populatePicker(picker: UIPickerView,
                                accessibilityIdentifier: String,
                                relativeTo: NSLayoutYAxisAnchor) -> UIPickerView {
        picker.accessibilityIdentifier = accessibilityIdentifier
        picker.delegate = self
        picker.dataSource = self
        picker.translatesAutoresizingMaskIntoConstraints = false
        containerView.addSubview(picker)
        NSLayoutConstraint.activate([
            picker.leadingAnchor.constraint(equalTo: containerView.leadingAnchor),
            picker.trailingAnchor.constraint(equalTo: containerView.trailingAnchor),
            picker.heightAnchor.constraint(equalToConstant: 100),
            picker.topAnchor.constraint(equalTo: relativeTo, constant: 5)
        ])
        return picker
    }
    
    func reloadPicker() {
        let userPickerData = loadDataFromPlist()
        pickerMap["userPicker"] = userPickerData
        userPicker.reloadAllComponents()
    }
    private func configureList() {
        entityPicker.reloadAllComponents()
        pickerMap[envPicker.accessibilityIdentifier!] = appEnvList
        envPicker.reloadAllComponents()
    }
    private func loadDataFromPlist() -> [String] {
        continueBtn.isEnabled = false
        continueBtn.backgroundColor = .gray
        configureList()
        let plistFile = retrivePickerValue(entityPicker).uppercased() + "_" + retrivePickerValue(envPicker).replacingOccurrences(of: " ", with: "_").replacingOccurrences(of: "-", with: "").uppercased()
        guard let path = Bundle.main.path(forResource: plistFile, ofType: "plist"), let plistXML = FileManager.default.contents(atPath: path) else {
            return []
        }
        
        var propertyListFormate = PropertyListSerialization.PropertyListFormat.xml
        var plistData: [String : AnyObject] = [:]
        
        do {
            plistData = try (PropertyListSerialization.propertyList(from: plistXML,
                                                                    options: .mutableContainersAndLeaves,
                                                                    format: &propertyListFormate) as? [String : AnyObject] ?? [String: AnyObject]())
        } catch {
            //Error While Reading Plist File
            print("Error: Whiel Reading Plist File Data!!!")
        }
        
        guard  let listUsers = plistData["USERS"] as? [String] else {
            return []
        }
        userlist = listUsers
        
        if !userlist.isEmpty {
            continueBtn.isEnabled = true
            continueBtn.backgroundColor = .red
        }
        
        return userlist
    }
    
    private func retrivePickerValue(_ picker: UIPickerView) -> String {
        let selectedRow = picker.selectedRow(inComponent: 0)
        let selectdValue = pickerMap[picker.accessibilityIdentifier!]![selectedRow]
        return selectdValue
    }
}
extension EntityEnvironmentViewController: UIPickerViewDelegate , UIPickerViewDataSource {
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
       return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return pickerMap![pickerView.accessibilityIdentifier!]!.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return pickerMap[pickerView.accessibilityIdentifier!]![row]
    }
   
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        if pickerView.accessibilityIdentifier! == "entityPicker" || pickerView.accessibilityIdentifier! == "envPicker" {
            reloadPicker()
        }
    }
}

