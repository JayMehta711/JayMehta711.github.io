//
//  BundleMarker.swift
//  ReferenceJourneyApp
//
//  Created by Jay Mehta on 13/06/21.
//

import Foundation
private class BundleMarker { }
let hostAppBundle = Bundle(for: BundleMarker.self)
