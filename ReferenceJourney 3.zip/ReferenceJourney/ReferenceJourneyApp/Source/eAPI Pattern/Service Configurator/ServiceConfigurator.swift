//
//  ServiceConfigurator.swift
//  ReferenceJourneyApp
//
//  Created by Jay Mehta on 08/06/21.
//

import Foundation

struct BuildEnvironment {
    static let fileMock = "FILE MOCK"
    static let cert = "CERT"
}

public class ServiceConfigurator {
    //Default entity is IN
    var selectedEntityCode: String = "IN"
    
    //Default Env is Mock
    var selectedEnv: String = BuildEnvironment.fileMock
    
    //Selected User
    var selectedUser: String = ""
    
    static let shareInstance = ServiceConfigurator()
    
    init() { }
    
}
