//
//  ReferenceJourneyAppProtocol.swift
//  ReferenceJourneyApp
//
//  Created by Jay Mehta on 08/06/21.
//

import Foundation

protocol ReferenceJourneyAppLauncherPreseterInterface: AnyObject {
    func presentLaunchScreen(withSelectedEntity: String, withSelectedEnv: String)
    func presentReferenceJourneyScreen()
}

protocol ReferenceJourneyAppLauncherInteractorInterface: AnyObject  { }
