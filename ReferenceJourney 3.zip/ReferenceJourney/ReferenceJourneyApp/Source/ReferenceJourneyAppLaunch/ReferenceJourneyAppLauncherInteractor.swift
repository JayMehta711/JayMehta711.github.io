//
//  ReferenceJourneyAppLauncherInteractor.swift
//  ReferenceJourneyApp
//
//  Created by Jay Mehta on 08/06/21.
//

import Foundation
final class  ReferenceJourneyAppLauncherInteractor: ReferenceJourneyAppLauncherInteractorInterface {
    var presenter: ReferenceJourneyAppLauncherPreseterInterface!
}
