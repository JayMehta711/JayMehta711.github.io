//
//  ReferenceJourneyAppLancherPresenter.swift
//  ReferenceJourneyApp
//
//  Created by Jay Mehta on 08/06/21.
//

import Foundation

final class ReferenceJourneyAppLancherPresenter: ReferenceJourneyAppLauncherPreseterInterface {
    var router: ReferenceJourneyAppRouter!
    var interector: ReferenceJourneyAppLauncherInteractorInterface!
    
    func presentLaunchScreen(withSelectedEntity: String, withSelectedEnv: String) {
        ServiceConfigurator.shareInstance.selectedEntityCode = withSelectedEntity
        ServiceConfigurator.shareInstance.selectedEnv = withSelectedEnv
        ServiceConfigurator.shareInstance.selectedUser = ""
        router.navigateToLauncherScreen()
    }
    
    func presentReferenceJourneyScreen() {
        router.navigateToRefenceJourneyController()
    }
}
