//
//  ReferenceJourneyAppRouter.swift
//  ReferenceJourneyApp
//
//  Created by Jay Mehta on 08/06/21.
//

import Foundation
import UIKit
import ReferenceJourney

final class ReferenceJourneyAppRouter {
    weak var viewController: EntityEnvironmentViewController?
    
    func navigateToLauncherScreen() {
        let launchViewController = LaunchViewController()
        launchViewController.presenter = viewController?.presenter
        viewController?.navigationController?.pushViewController(launchViewController, animated: true)
    }
    
    func navigateToRefenceJourneyController() {
        guard let parentNavigationController = self.viewController?.navigationController else {
            return
        }
        let configuration = ReferenceJourneyConfiguration()
        let referenceJourneyHomeViewController = ReferenceJourneyFactory.makeViewController(for: configuration,
                                                                                            containerNavigationController: parentNavigationController)
        viewController?.navigationController?.pushViewController(referenceJourneyHomeViewController, animated: true)
    }
}
