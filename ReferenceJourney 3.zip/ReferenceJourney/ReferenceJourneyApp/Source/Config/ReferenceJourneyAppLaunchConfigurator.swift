//
//  ReferenceJourneyAppLaunchConfigurator.swift
//  ReferenceJourneyApp
//
//  Created by Jay Mehta on 08/06/21.
//

import Foundation
import UIKit

final class ReferenceJourneyAppLaunchConfigurator {
    //Configure initial view of Framework for launch
    func configViewController() -> UIViewController {
        let viewController = EntityEnvironmentViewController()
        let presenter = ReferenceJourneyAppLancherPresenter()
        let router = ReferenceJourneyAppRouter()
        let interector = ReferenceJourneyAppLauncherInteractor()
        interector.presenter = presenter
        presenter.router = router
        presenter.interector = interector
        viewController.presenter = presenter
        router.viewController = viewController
        
        return viewController 
    }
    
    //Temp 
}
