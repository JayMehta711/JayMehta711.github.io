//
//  HaseFont.swift
//  ReferenceJourneyApp
//
//  Created by Jay Mehta on 14/06/21.
//

import Foundation
import UIKit

protocol HaseFont {
    static var familyName: String { get }
    static var light: String { get }
    static var regular: String { get }
    static var medium: String? { get }
    static var semibold: String? { get }
}

extension HaseFont {
    static func fontWith(size: CGFloat, weight: UIFont.Weight) -> UIFont? {
        UIFont(name: constructFontNameWith(weight: weight), size: size)
    }
    
    private static func constructFontNameWith(weight: UIFont.Weight) -> String {
        let postFix: String
        switch weight {
        case .light:
               postFix = light
        case .regular:
                postFix = regular
        case .medium:
              postFix = medium ?? regular
        case .semibold:
            postFix = semibold ?? regular
        default:
            postFix = regular
        }
        return "\(familyName)-\(postFix)"
    }
}

struct Roboto: HaseFont {
    static var familyName: String { "Roboto" }
    static var light: String { "Light" }
    static var regular: String { "Regular" }
    static var medium: String? { "Medium" }
    static var semibold: String? { nil }
}
