//
//  ThemeSelector.swift
//  ReferenceJourneyApp
//
//  Created by Jay Mehta on 14/06/21.
//

import ReferenceJourney
import UIKit

final class ThemeSelector {
    var currentBrand: Theme.Brand {
        didSet {
            themeManager.applyTheme(for: currentBrand, customFontGenerator: customFontGenerator)
        }
    }
    
    private let themeManager: ThemeManager
    
    private var customFontGenerator: FontGenerator? {
        switch currentBrand {
        case .jm:
            return { size, weight in
                if size >= 15 {
                    return Roboto.fontWith(size: size, weight: weight) ?? UIFont.systemFont(ofSize: size , weight: weight)
                } else {
                   return UIFont.systemFont(ofSize: size , weight: weight)
                }
            }
        default:
            return nil
        }
    }
    
    init(brand: Theme.Brand, themeManager: ThemeManager = ThemeManager.shared) {
        currentBrand = brand
        self.themeManager = themeManager
        
        themeManager.applyTheme(for: currentBrand, customFontGenerator: customFontGenerator)
    }
}
