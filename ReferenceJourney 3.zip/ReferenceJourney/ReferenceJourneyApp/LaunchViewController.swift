//
//  LaunchViewController.swift
//  ReferenceJourneyApp
//
//  Created by Jay Mehta on 08/06/21.
//

import UIKit

class LaunchViewController: UIViewController {
    var presenter: ReferenceJourneyAppLauncherPreseterInterface!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        setNavBar()
        setupView()
    }
    
    private func setNavBar() {
        navigationItem.title = "Launch Screen"
        navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: .plain, target: nil, action: nil)
    }
    
    private func setupView() {
        view.backgroundColor = .white
        let button = UIButton()
        view.addSubview(button)
        button.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
            button.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            button.heightAnchor.constraint(equalToConstant: 44),
            button.topAnchor.constraint(equalTo: view.layoutMarginsGuide.topAnchor, constant: 44),
            button.leadingAnchor.constraint(equalTo: view.layoutMarginsGuide.leadingAnchor, constant: 16),
            button.trailingAnchor.constraint(equalTo: view.layoutMarginsGuide.trailingAnchor, constant: -16)
        ])
        button.setTitle("Launch ReferenceJourney", for: .normal)
        button.backgroundColor = .red
        button.addTarget(self, action: #selector(buttonAction(sender:)), for: .touchUpInside)
    }

    @objc func buttonAction(sender: UIButton) {
        presenter.presentReferenceJourneyScreen()
    }

}
