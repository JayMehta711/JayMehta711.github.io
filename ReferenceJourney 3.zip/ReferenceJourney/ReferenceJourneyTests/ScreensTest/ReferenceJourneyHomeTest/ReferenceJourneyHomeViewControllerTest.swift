//
//  ReferenceJourneyHomeViewControllerTest.swift
//  ReferenceJourneyTests
//
//  Created by Jay Mehta on 21/08/22.
//

import XCTest
@testable import ReferenceJourney

class ReferenceJourneyHomeViewControllerTest: XCTestCase {

    func testReferenceJourneyHomeViewController() {
        let config = ConfigurationStub().getStubConfiguration()
        let interector = ReferenceJourneyHomeInterector(configuration: config)
        let router = ReferenceJourneyRouter.init(configuration: config)
        let view = ReferenceJourneyHomeViewController.init()
        let presenter = ReferenceJourneyHomePresenter(configuration: config,
                                                      router: router,
                                                      interector: interector,
                                                      view: view)
        
        view.setPresenter(presenter: presenter)
        XCTAssertNotNil(presenter)
        XCTAssertNotNil(view)
    }
    
    func testOnboardingButtonHomeScreen() {
        let view = ReferenceJourneyHomeViewController.init()
        let presenter = ReferenceJourneyHomePresenterStub()
        view.setPresenter(presenter: presenter)
        XCTAssertFalse(presenter.isPresentOnboardingScreenCalled)
        view.buttonAction(sender: UIButton())
        XCTAssertTrue(presenter.isPresentOnboardingScreenCalled)
    }
    
    func testHomeScreenDismissOnboardingScreen() {
        let view = ReferenceJourneyHomeViewController.init()
        let presenter = ReferenceJourneyHomePresenterStub()
        view.setPresenter(presenter: presenter)
        XCTAssertFalse(presenter.isDismissOnboardingScreenCalled)
        view.onboardingViewControllerDidCancel()
        XCTAssertTrue(presenter.isDismissOnboardingScreenCalled)

    }
}
