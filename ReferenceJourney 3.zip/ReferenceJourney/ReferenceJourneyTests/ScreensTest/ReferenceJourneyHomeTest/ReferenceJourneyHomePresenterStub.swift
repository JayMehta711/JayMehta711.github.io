//
//  ReferenceJourneyHomePresenterStub.swift
//  ReferenceJourneyTests
//
//  Created by Jay Mehta on 21/08/22.
//

import Foundation
@testable import ReferenceJourney

final class ReferenceJourneyHomePresenterStub: ReferenceJourneyHomePresenterInterface {
    var isPresentOnboardingScreenCalled: Bool = false
    var isDismissOnboardingScreenCalled: Bool = false
    
    func presentOnboardingScreen() {
        isPresentOnboardingScreenCalled = true
    }
    
    func dismissOnboardingScreen() {
        isDismissOnboardingScreenCalled = true
    }
}
