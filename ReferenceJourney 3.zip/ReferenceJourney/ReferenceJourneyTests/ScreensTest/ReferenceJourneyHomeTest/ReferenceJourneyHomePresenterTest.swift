//
//  ReferenceJourneyHomePresenterTest.swift
//  ReferenceJourneyTests
//
//  Created by Jay Mehta on 21/08/22.
//

import XCTest
@testable import ReferenceJourney

class ReferenceJourneyHomePresenterTest: XCTestCase {
    
    var presenter: ReferenceJourneyHomePresenter!
    var router: ReferenceJourneyRouterStub!
    
    override func setUp() {
        let config = ConfigurationStub().getStubConfiguration()
        let interector = ReferenceJourneyHomeInterector(configuration: config)
        router = ReferenceJourneyRouterStub()
        let view = ReferenceJourneyHomeViewController.init()
        presenter = ReferenceJourneyHomePresenter(configuration: config,
                                                      router: router,
                                                      interector: interector,
                                                      view: view)
        XCTAssertNotNil(presenter)
    }
    
    override func tearDown() {
        presenter = nil
    }
    
    func testReferenceJourneyHomePresenter() {
        let config = ConfigurationStub().getStubConfiguration()
        let interector = ReferenceJourneyHomeInterector(configuration: config)
        let router = ReferenceJourneyRouter.init(configuration: config)
        let view = ReferenceJourneyHomeViewController.init()
        let presenter = ReferenceJourneyHomePresenter(configuration: config,
                                                      router: router,
                                                      interector: interector,
                                                      view: view)
        XCTAssertNotNil(presenter)
    }
   
    func testOnboardingScreen() {
        presenter.presentOnboardingScreen()
        XCTAssertTrue(router.isNavToOnboardingScreen)
    }
    func testOnboardingDismissScreen() {
        presenter.dismissOnboardingScreen()
        XCTAssertTrue(router.isPopToCurrentViewController)
    }
}

