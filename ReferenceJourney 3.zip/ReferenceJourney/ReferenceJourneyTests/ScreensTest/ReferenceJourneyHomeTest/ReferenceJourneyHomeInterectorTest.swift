//
//  ReferenceJourneyHomeInterectorTest.swift
//  ReferenceJourneyTests
//
//  Created by Jay Mehta on 21/08/22.
//

import XCTest
@testable import ReferenceJourney

class ReferenceJourneyHomeInterectorTest: XCTestCase {

    func testReferenceJourneyHomeInterector() {
        let config = ConfigurationStub().getStubConfiguration()
        let interector = ReferenceJourneyHomeInterector(configuration: config)
        XCTAssertNotNil(interector)
    }

}
