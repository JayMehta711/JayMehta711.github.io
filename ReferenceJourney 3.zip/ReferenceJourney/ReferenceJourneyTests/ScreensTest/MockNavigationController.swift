//
//  MockNavigationController.swift
//  ReferenceJourneyTests
//
//  Created by Jay Mehta on 21/08/22.
//

import Foundation
import UIKit

final class MockNavigationController: UINavigationController {
    private(set) var isPresented = false
    private(set) var isPushed = false
    private(set) var isPopped = false
    private(set) var isDismissed = false
    
    override func present(_ viewControllerToPresent: UIViewController, animated flag: Bool, completion: (() -> Void)? = nil) {
        super.present(viewControllerToPresent, animated: flag, completion: completion)
        isPresented = true
    }
    
    override func pushViewController(_ viewController: UIViewController, animated: Bool) {
        super.pushViewController(viewController, animated: animated)
        isPushed = true
    }
    
    override func popViewController(animated: Bool) -> UIViewController? {
        isPopped = true
        return super.popViewController(animated: animated)
    }
}
