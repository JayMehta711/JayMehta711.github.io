//
//  ReferenceJourneyRouterTest.swift
//  ReferenceJourneyTests
//
//  Created by Jay Mehta on 21/08/22.
//

import XCTest
@testable import ReferenceJourney

class ReferenceJourneyRouterTest: XCTestCase {
    
    private var router: ReferenceJourneyRouter!
    private var navigationController: MockNavigationController!
    private var config: ReferenceJourneyConfiguration!
    
    override func setUp() {
        config = ConfigurationStub.init().getStubConfiguration()
        router = ReferenceJourneyRouter.init(configuration: config)
        navigationController = MockNavigationController()
        let homeVC = ReferenceJourneyFactory.makeReferenceJourneyHomeController(router: router, configuration: config)
        //ReferenceJourneyFactory.makeViewController(for: config, containerNavigationController: navigationController)
        router.setNavigationController(navigationController)
        navigationController.pushViewController(homeVC, animated: true)
        ThemeManager.shared.applyTheme(for: .jm, customFontGenerator: nil)
    }
    
    override func tearDown() {
        config = nil
        router = nil
        navigationController = nil
    }
    func testNavigationToOnboaringScreen() {
        router.navigateToOnBoardingscreen()
        XCTAssertTrue(navigationController.isPushed, "Onboarding Screen should be pushed")
    }
    
    func testPopToViewControllerScreen() {
        router.popCurrentViewController()
        XCTAssertTrue(navigationController.isPopped, "ViewController from CurrentNavigationController  should be poped")
    }
}
