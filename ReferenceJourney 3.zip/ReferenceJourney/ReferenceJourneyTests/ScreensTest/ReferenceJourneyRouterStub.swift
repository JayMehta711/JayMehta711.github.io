//
//  ReferenceJourneyRouterStub.swift
//  ReferenceJourneyTests
//
//  Created by Jay Mehta on 21/08/22.
//

import Foundation
@testable import ReferenceJourney


class ReferenceJourneyRouterStub: ReferenceJourneyRouterInterface {
    private(set) var isNavToOnboardingScreen: Bool = false
    private(set) var isPopToCurrentViewController: Bool = false
    
    func popCurrentViewController() {
        isPopToCurrentViewController = true
    }
    
    func navigateToOnBoardingscreen() {
        isNavToOnboardingScreen = true
    }
}
