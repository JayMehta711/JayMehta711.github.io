//
//  ConfigurationStub.swift
//  ReferenceJourneyTests
//
//  Created by Jay Mehta on 21/08/22.
//

import Foundation
import ReferenceJourney


class ConfigurationStub {
     init() { }
    
    func getStubConfiguration() -> ReferenceJourneyConfiguration {
        let config = ReferenceJourneyConfiguration()
        return config
    }
}
