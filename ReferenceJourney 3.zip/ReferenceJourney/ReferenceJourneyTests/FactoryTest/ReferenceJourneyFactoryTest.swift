//
//  ReferenceJourneyFactoryTest.swift
//  ReferenceJourneyTests
//
//  Created by Jay Mehta on 21/08/22.
//

import XCTest
@testable import ReferenceJourney

class ReferenceJourneyFactoryTest: XCTestCase {

    func testReferenceJourneyHomeViewControllerFactory() {
        let config = ConfigurationStub().getStubConfiguration()
        let router = ReferenceJourneyRouter.init(configuration: config)
        let vc = ReferenceJourneyFactory.makeReferenceJourneyHomeController(router: router, configuration: config)
        XCTAssertNotNil(vc)
    }
    
    func testReferenceJourneyFactory() {
        let config = ConfigurationStub().getStubConfiguration()
        let vc = ReferenceJourneyFactory.makeViewController(for: config, containerNavigationController: nil)
        XCTAssertNotNil(vc)
    }
    
    func testReferenceJourneyFactoryWithNavigation() {
        let config = ConfigurationStub().getStubConfiguration()
        let nav = UINavigationController.init()
        let vc = ReferenceJourneyFactory.makeViewController(for: config, containerNavigationController: nav)
        XCTAssertNotNil(vc)
    }
}
