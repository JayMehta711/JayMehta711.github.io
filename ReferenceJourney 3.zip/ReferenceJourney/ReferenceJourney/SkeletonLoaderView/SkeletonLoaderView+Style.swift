//
//  SkeletonLoaderView+Style.swift
//  ReferenceJourney


import Foundation
import UIKit
extension SkeletonLoaderView {
    struct Style {
       // let backgroundColorPath: Them
    }
}
