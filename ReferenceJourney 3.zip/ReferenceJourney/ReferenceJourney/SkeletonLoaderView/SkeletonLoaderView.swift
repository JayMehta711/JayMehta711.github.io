//
//  SkeletonLoaderView.swift
//  ReferenceJourney


import Foundation
import UIKit

public protocol SkeletonLoaderAnimation {
    func startAnimation()
    func stopAnimation()
}

public protocol ShimmerableSkeleton {
    //List of views on which SkeletonLoaderView will apply the mask view and animation on it.
    
    func skeletonViewsToAnimation() -> [UIView]
    
}

class AnimatableView: UIView {
    var gradient: CAGradientLayer?
}

public class SkeletonLoaderView: UIView,SkeletonLoaderAnimation {
    
    private enum ConstantsSkeletonLoader {
        static let layerName = "SkeletonLoaderView"
        static let animationKeyPath = "transform.translation.x"
        static let animationKey = "ShimmerAnimation"
        static let animationDuration = 1.0
    }
    
    public private(set) var isAnimating: Bool = false
    private var theme: Theme {
        didSet {
            reapplyAnimation()
        }
    }
    
    private var animatingViews = [AnimatableView]()
    private let shimmeringView : ShimmerableSkeleton
    
    
    init(shimmerable: ShimmerableSkeleton,
         startAnimation: Bool = true,
         themeManager: ThemeManager = ThemeManager.shared) {
        shimmeringView = shimmerable
        theme = themeManager.currentTheme
        super.init(frame: CGRect.zero)
        
        setupView(startAnimation)
    }
    
    @available(*,unavailable)
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func setupView(_ startAnimation: Bool) {
        
        if startAnimation {
            // startAnimation()
        }
    }
    
    private func addAnimationView() {
        let views = shimmeringView.skeletonViewsToAnimation()
        
        views.forEach { view in
            guard let superView = view.superview else {
                return
            }
            
            let hidingView = AnimatableView()
            hidingView.clipsToBounds = true
            hidingView.translatesAutoresizingMaskIntoConstraints = false
            superView.addSubview(hidingView)
            superView.bringSubviewToFront(hidingView)
            animatingViews.append(hidingView)
            
            NSLayoutConstraint.activate([
                hidingView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
                hidingView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
                hidingView.topAnchor.constraint(equalTo: view.topAnchor),
                hidingView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
            ])
            
            hidingView.backgroundColor = theme.colors.backgroundStandard
            
        }
        
    }
    
    public func startAnimation() {
        
    }
    
    public func stopAnimation() {
        
    }
    private func reapplyAnimation() {
        guard isAnimating else { return }
        stopAnimation()
        startAnimation()
    }
}
