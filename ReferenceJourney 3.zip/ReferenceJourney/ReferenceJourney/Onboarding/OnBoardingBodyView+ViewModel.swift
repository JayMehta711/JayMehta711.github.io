//
//  OnBoardingBodyView+ViewModel.swift
//  ReferenceJourney
//
//  Created by Jay Mehta on 28/05/21.
//

import Foundation
import UIKit

extension OnBoardingBodyView {
    typealias  OnTapURLActionHandler = (URL,String?) -> Void
    struct ViewModel {
        let title: String
        let description: String
        let onLinkClicked: OnTapURLActionHandler
    
    
     init(titleText: String,
         descriptionText: String,
         onLinkTapped: @escaping OnTapURLActionHandler) {
        self.title = titleText
        self.description = descriptionText
        onLinkClicked = onLinkTapped
    }
        
    }
}
