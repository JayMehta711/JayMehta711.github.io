//
//  OnboardingScreenViewController+ViewModel.swift
//  ReferenceJourney
//
//  Created by Jay Mehta on 28/05/21.
//

import Foundation
import UIKit

extension OnboardingScreenViewController {
    public struct ViewModel {
        
        public let headerImage: UIImage
        public let title: String
        public let descrption: String
        public let primaryButtonTitle: String
        
        
        public init(
            headerImage: UIImage,
            title: String,
            descrption: String,
            primaryButtonTitle: String
            ) {
            self.headerImage = headerImage
            self.title = title
            self.descrption = descrption
            self.primaryButtonTitle = primaryButtonTitle
        }
    }
}
