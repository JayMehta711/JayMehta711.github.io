//
//  OnBoardingBodyView.swift
//  ReferenceJourney
//
//  Created by Jay Mehta on 28/05/21.
//

import Foundation
import UIKit

final class OnBoardingBodyView: UIView {
    
    private enum Constants {
        static let mediumPadding: CGFloat = 8
        static let titlePadding: CGFloat = 16
        static let subtitlePadding: CGFloat = 16
        static let bodyStackViewSpacing: CGFloat = 16
    }
    
    private var bodyStackView: UIStackView  = {
        var bodyStackView = UIStackView()
        bodyStackView.axis = .vertical
        bodyStackView.spacing = Constants.bodyStackViewSpacing
        bodyStackView.translatesAutoresizingMaskIntoConstraints = false
        bodyStackView.distribution = .fill
        return bodyStackView
    }()
    
    private lazy var titleLabel: UILabel = {
        var titleLabel = UILabel(frame: CGRect.zero)
        titleLabel.translatesAutoresizingMaskIntoConstraints = false
        titleLabel.numberOfLines = 0
        titleLabel.adjustsFontForContentSizeCategory = true
        titleLabel.accessibilityTraits = .header
        return titleLabel
    }()
    
    private var descriptionTextView: UITextView =  {
       let textView = UITextView()
        textView.dataDetectorTypes = .all
        textView.textContainerInset = .zero
        textView.textContainer.lineFragmentPadding = 0
        textView.contentInset = .zero
        textView.translatesAutoresizingMaskIntoConstraints = false
        textView.isEditable = false
        textView.adjustsFontForContentSizeCategory = true
        textView.isScrollEnabled = false
        textView.accessibilityTraits = .staticText
        return textView
    }()

    private let viewModel: ViewModel
    
    init(viewModel: ViewModel) {
        self.viewModel = viewModel
        super.init(frame: .zero)
        translatesAutoresizingMaskIntoConstraints = false
        setupViews()
        setTexts()
    }
    
    @available(*,unavailable)
    required init?(coder: NSCoder) {
        fatalError("object can not be instantiated from Interface Builder")
    }
    
    private func setupViews() {
        addSubview(bodyStackView)
        
        let titleContainerView = UIView(frame: .zero)
        titleContainerView.translatesAutoresizingMaskIntoConstraints = false
        titleContainerView.addSubview(titleLabel)
        bodyStackView.addArrangedSubview(titleContainerView)
        
        let bodyContainerView = UIView(frame: .zero)
        bodyContainerView.translatesAutoresizingMaskIntoConstraints = false
        bodyContainerView.addSubview(descriptionTextView)
        bodyStackView.addArrangedSubview(bodyContainerView)
        descriptionTextView.delegate = self
        
        NSLayoutConstraint.activate(
         [
            bodyStackView.leadingAnchor.constraint(equalTo: leadingAnchor),
            bodyStackView.trailingAnchor.constraint(equalTo: trailingAnchor),
            bodyStackView.topAnchor.constraint(equalTo: topAnchor, constant: Constants.mediumPadding),
            bodyStackView.bottomAnchor.constraint(equalTo: bottomAnchor, constant: Constants.mediumPadding),
            titleLabel.topAnchor.constraint(equalTo: titleContainerView.topAnchor),
            titleLabel.leadingAnchor.constraint(equalTo: titleContainerView.leadingAnchor,
                                                constant: Constants.titlePadding),
            titleLabel.trailingAnchor.constraint(equalTo: titleContainerView.trailingAnchor,
                                                 constant: -Constants.titlePadding),
            titleLabel.bottomAnchor.constraint(equalTo: titleContainerView.bottomAnchor),
            titleContainerView.heightAnchor.constraint(equalTo: titleLabel.heightAnchor),
            descriptionTextView.topAnchor.constraint(equalTo: bodyContainerView.topAnchor),
            descriptionTextView.leadingAnchor.constraint(equalTo: bodyContainerView.leadingAnchor,
                                                constant: Constants.subtitlePadding),
            descriptionTextView.trailingAnchor.constraint(equalTo: bodyContainerView.trailingAnchor,
                                                 constant: -Constants.subtitlePadding),
            descriptionTextView.bottomAnchor.constraint(equalTo: bodyContainerView.bottomAnchor),
         ]
        )
    }
    
    private func setTexts() {
        titleLabel.text = viewModel.title
        descriptionTextView.text = viewModel.description
    }
}

extension OnBoardingBodyView: UITextViewDelegate {
    
    func textView(_ textView: UITextView,
                  shouldInteractWith URL: URL,
                  in characterRange: NSRange,
                  interaction: UITextItemInteraction) -> Bool {
        //prevent textview from opning a preview (iOS 13)
        guard  interaction == .invokeDefaultAction else {
            return false
        }
        
        //prevent textView from opning URL on user scrolling the textView or parent view
        guard let isTapGesture = textView.gestureRecognizers?.contains(where: { $0.isKind(of: UITapGestureRecognizer.self) && $0.state == .ended }) , isTapGesture else {
            return true
        }
        viewModel.onLinkClicked(URL,(textView.text as NSString).substring(with: characterRange))
        return false
    }
}
