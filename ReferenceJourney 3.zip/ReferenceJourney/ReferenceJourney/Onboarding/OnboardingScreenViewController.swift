//
//  OnboardingScreenViewController.swift
//  ReferenceJourney
//
//  Created by Jay Mehta on 28/05/21.
//

import Foundation
import UIKit

protocol OnboardingViewDelegate: AnyObject {
    func onboardingViewControllerDidCancel()
    func onboardingViewControllerDidContinue()
    func onboardingViewControllerDidTapURL(_ url: URL, text: String?)
}

final class OnboardingScreenViewController: UIViewController {
    
    private enum Constants {
        static let contentVerticalSpacing: CGFloat = 8
        static let padding: CGFloat = 16
        static let buttonTopSpacing: CGFloat = 8
    }
    
    private var contentView: UIView = {
        let contentView = UIView(frame: .zero)
        contentView.translatesAutoresizingMaskIntoConstraints = false
        return contentView
    }()
    
    private lazy var scrollView: UIScrollView = {
        let scrollView = UIScrollView(frame: .zero)
        scrollView.translatesAutoresizingMaskIntoConstraints = false
        scrollView.clipsToBounds = true
        scrollView.delegate = self
        scrollView.contentInsetAdjustmentBehavior = .never
        scrollView.accessibilityIdentifier = "scrollView"
        return scrollView
    }()
    
    private var navigationBarBackgroundView: UIView = {
        let view = UIView()
        view.translatesAutoresizingMaskIntoConstraints = false
        view.alpha = 0
        view.accessibilityIdentifier = "navigationBarBackgroundView"
        return view
    }()
    
    private(set) lazy var headerImageView: UIImageView = {
        let image = viewModel.headerImage
        let imageView = UIImageView(image: image)
        imageView.translatesAutoresizingMaskIntoConstraints = false
        return imageView
    }()
    
    private var contentStackView: UIStackView = {
        let contentStackView: UIStackView = UIStackView(frame: .zero)
        contentStackView.translatesAutoresizingMaskIntoConstraints = false
        contentStackView.axis = .vertical
        contentStackView.distribution = .fill
        contentStackView.alignment = .fill
        contentStackView.spacing = Constants.contentVerticalSpacing
        return contentStackView
    }()
    
    private(set) lazy var actionButton: UIButton =  {
        let button = UIButton(frame: .zero)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.setTitle(viewModel.primaryButtonTitle, for: .normal)
        button.clipsToBounds = true
        button.setTitleColor(UIColor.white, for: .normal)
        return button
    }()
    
    let viewModel: ViewModel
    private let supportedSchemes = ["http", "https"]
    public weak var delegate:OnboardingViewDelegate?
    
    public init(
        viewModel: ViewModel
    ){
        self.viewModel = viewModel
        super.init(nibName: nil, bundle: nil)
    }
    
    @available(*,unavailable)
    required init?(coder: NSCoder) {
        fatalError("Object can not be instantiated from Interface Builder.")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let item = UIBarButtonItem(barButtonSystemItem: .stop, target: self, action: #selector(dismissAction))
        navigationItem.hidesBackButton = true
        navigationItem.setLeftBarButton(item, animated: false)
        setupViews()
    }
    
    @objc private func dismissAction() {
        delegate?.onboardingViewControllerDidCancel()
    }
    
    private func setupViews() {
        view.backgroundColor = ThemeManager.shared.currentTheme.colors.backgroundHiglighted
        view.addSubview(scrollView)
        //navigationBarBackgroundView should always be added to the view hierarchy after the scrollView
        view.addSubview(navigationBarBackgroundView)
        view.addSubview(actionButton)
        scrollView.addSubview(contentView)
        contentView.addSubview(contentStackView)
        contentStackView.addArrangedSubview(headerImageView)
        let bodyViewModel = OnBoardingBodyView.ViewModel.init(titleText: viewModel.title, descriptionText: viewModel.descrption, onLinkTapped: { [weak self] in self?.didTapURL($0, text: $1)})
        
        let bodyView = OnBoardingBodyView(viewModel: bodyViewModel)
        contentStackView.addArrangedSubview(bodyView)
        setupConstraints(bodyView)
        
        actionButton.titleLabel?.font = ThemeManager.shared.currentTheme.fonts.button
        actionButton.backgroundColor = ThemeManager.shared.currentTheme.colors.primaryButton
        actionButton.setTitleColor(ThemeManager.shared.currentTheme.colors.backgroundHiglighted, for: .normal)
        actionButton.addTarget(self, action: #selector(continueAction), for: .touchUpInside)
    }
    
    private func setupConstraints(_ bodyView: OnBoardingBodyView) {
        let contentViewBottomConstraint = contentView.bottomAnchor.constraint(equalTo: bodyView.bottomAnchor)
        contentViewBottomConstraint.priority = .defaultLow
        let headerImage = viewModel.headerImage
        NSLayoutConstraint.activate([
            navigationBarBackgroundView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            navigationBarBackgroundView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            navigationBarBackgroundView.topAnchor.constraint(equalTo: view.topAnchor),
            navigationBarBackgroundView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            contentStackView.topAnchor.constraint(equalTo: contentView.topAnchor),
            contentStackView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor),
            contentStackView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor),
            contentStackView.widthAnchor.constraint(equalTo: scrollView.widthAnchor),
            contentView.topAnchor.constraint(equalTo: scrollView.topAnchor),
            contentView.leadingAnchor.constraint(equalTo: scrollView.leadingAnchor),
            contentView.trailingAnchor.constraint(equalTo: scrollView.trailingAnchor),
            contentView.bottomAnchor.constraint(equalTo: scrollView.bottomAnchor),
            contentViewBottomConstraint,
            actionButton.leadingAnchor.constraint(equalTo: view.leadingAnchor,constant: Constants.padding),
            actionButton.trailingAnchor.constraint(equalTo: view.trailingAnchor,constant: -Constants.padding),
            actionButton.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor,
                                                 constant:  -Constants.padding),
            scrollView.topAnchor.constraint(equalTo: view.topAnchor),
            scrollView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            scrollView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            scrollView.bottomAnchor.constraint(equalTo: actionButton.topAnchor, constant: -Constants.buttonTopSpacing),
            headerImageView.heightAnchor.constraint(equalTo: headerImageView.widthAnchor, multiplier: headerImage.size.height / headerImage.size.width)
            
        ])
        
    }
    
    
    private func didTapURL(_ url: URL, text: String?) {
        guard let scheme = url.scheme , supportedSchemes.contains(scheme) else {
            return
        }
        
        delegate?.onboardingViewControllerDidTapURL(url, text: text)
    }
    
    @objc func continueAction(){
        delegate?.onboardingViewControllerDidContinue()
    }
}

extension OnboardingScreenViewController: UIScrollViewDelegate {
    
    public func scrollViewDidScroll(_ scrollView: UIScrollView) {
        let alpha = scrollView.contentOffset.y / (headerImageView.frame.height - view.safeAreaInsets.top)
        navigationBarBackgroundView.alpha = fmax(0,alpha)
    }
}
