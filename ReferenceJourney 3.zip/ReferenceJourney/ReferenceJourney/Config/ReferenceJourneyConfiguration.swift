//
//  ReferenceJourneyConfiguration.swift
//  ReferenceJourney
//
//  Created by Jay Mehta on 08/06/21.
//

import Foundation
public class ReferenceJourneyConfiguration {
    public init() { }
}
