//
//  ReferenceJourneyOnboardingFactory.swift
//  ReferenceJourney
//
//  Created by Jay Mehta on 13/06/21.
//

import Foundation
import UIKit
enum ReferenceJourneyOnboardingFactory {
    static func makeNewOnboardingViewController(viewData: OnboardingScreenViewController.ViewModel, delegate: OnboardingViewDelegate?) -> UIViewController {
        let viewController = OnboardingScreenViewController(viewModel: viewData)
        viewController.delegate = delegate
        return viewController
    }
}
 
