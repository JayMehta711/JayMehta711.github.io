//
//  ReferenceJourneyFactory.swift
//  ReferenceJourney
//
//  Created by Jay Mehta on 08/06/21.
//

import Foundation
import UIKit
public enum ReferenceJourneyFactory {
    
    public static func makeViewController(for configuration: ReferenceJourneyConfiguration,
                                          containerNavigationController: UINavigationController?) -> UIViewController {
        
        
        let router = ReferenceJourneyRouter(configuration: configuration)
        let refereceJourneyHomeView = makeReferenceJourneyHomeController(router: router,
                                                                         configuration: configuration)
        if let containerNavigationController = containerNavigationController {
            router.setNavigationController(containerNavigationController)
            return refereceJourneyHomeView
        } else {
            
            let viewController = ReferenceJourneyFactory.makeContainerNavigationController(refereceJourneyHomeView)
            router.setNavigationController(viewController)
            return viewController
        }
    }
    
    static func makeReferenceJourneyHomeController(router: ReferenceJourneyRouterInterface,
                                                   configuration: ReferenceJourneyConfiguration) -> UIViewController {
        let refereceJourneyHomeView = ReferenceJourneyHomeViewController()
        let interectorHome = ReferenceJourneyHomeInterector(configuration: configuration)
        let presenterHome = ReferenceJourneyHomePresenter(configuration: configuration,
                                                          router: router,
                                                          interector: interectorHome,
                                                          view: refereceJourneyHomeView)
        refereceJourneyHomeView.setPresenter(presenter: presenterHome)
        return refereceJourneyHomeView
    }
    
    //Make navigation controller, in case host application does not provide one
    private static func makeContainerNavigationController(_ rootViewController: UIViewController) -> UINavigationController {
        let navigationController = UINavigationController(rootViewController: rootViewController)
        return navigationController
    }
}
