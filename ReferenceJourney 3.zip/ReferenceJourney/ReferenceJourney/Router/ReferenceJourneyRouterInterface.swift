//
//  ReferenceJourneyRouterInterface.swift
//  ReferenceJourney
//
//  Created by Jay Mehta on 08/06/21.
//

import Foundation

protocol ReferenceJourneyRouterInterface {
    func popCurrentViewController()
    func navigateToOnBoardingscreen()
}
