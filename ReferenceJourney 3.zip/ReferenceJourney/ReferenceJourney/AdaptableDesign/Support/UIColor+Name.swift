//
//  UIColor+Name.swift
//  ReferenceJourney
//
//  Created by Jay Mehta on 14/06/21.
//

import UIKit
extension UIColor {
    static func color(from baseFolder: String, named name: String, in bundle: Bundle = designBundle) -> UIColor? {
        UIColor(named: "\(baseFolder)/\(name)", in: bundle ,compatibleWith: nil)
    }
    static func dynamicColorWith(defaultColor: UIColor, darkColor: UIColor? = nil) -> UIColor {
        if #available(iOS 13.0, *), let darkColor = darkColor {
            return UIColor(dynamicProvider:  {$0.userInterfaceStyle == .dark ? darkColor : defaultColor })
        } else {
            return defaultColor
        }
    }
    
}
