//
//  Theme+Paletter.swift
//  ReferenceJourney
//
//  Created by Jay Mehta on 14/06/21.
//

import UIKit
protocol ThemePalette {
    static var semanticColors: Theme.SemanticColors { get }
    static func makeSemanticFonts(from fontGenerator: FontGenerator, fontMetrics: UIFontMetrics) -> Theme.SemanticFonts
}

extension Theme {
    
    public struct SemanticColors {
        //Genereic fill colors
        public let primary: UIColor
        
        public let selection: UIColor
        public let disabled: UIColor
        public let success: UIColor
        public let warning: UIColor
        public let error: UIColor
        public let successBorder: UIColor
        
        //Generic text colors
        public let textPrimary: UIColor
        public let textSecondary: UIColor
        public let textPlaceholder: UIColor
        
        
        //Generic layout colors
        public let backgroundStandard: UIColor
        public let backgroundHiglighted: UIColor
        public let dimmedBackground: UIColor
        public let bottomNavBar: UIColor
        
        //Component Colors Buttons
        public let primaryButton: UIColor
        public let textPrimaryButton: UIColor
        
        //Component colors - NavigationBar
        public let defaultNavigationBarBackgroundColor: UIColor
        public let defaultNavigationBarTintColor: UIColor
        public let transparentNavigationBarTintColor: UIColor
        
    }
    
    //MARK: Semantic Fonts
    public struct SemanticFonts {
        //Generic typography
        
        public let display: UIFont
        public let displayEmphasized: UIFont
        public let headline: UIFont
        public let headiline2: UIFont
        public let title1: UIFont
        public let titleLight: UIFont
        public let body: UIFont
        public let bodyEmphasized: UIFont
        
        
        //Component specific typhography
        public let button: UIFont
        public let buttonIcon: UIFont
        public let tabBarActive: UIFont
        public let tabBarInactive: UIFont
        
    }
}
