//
//  MSPalette.swift
//  ReferenceJourney
//
//  Created by Jay Mehta on 14/06/21.
//

import UIKit

enum  MSPalette: ThemePalette {
    
    
    //MARK: Colors
    
    private enum Colors {
        private static let baseFolder = "MS"
        static var c01: UIColor { UIColor.color(from: baseFolder, named: "C01")! }
        static var c02: UIColor { UIColor.color(from: baseFolder, named: "C02")! }
        static var c03: UIColor { UIColor.color(from: baseFolder, named: "C03")! }
        static var c04: UIColor { UIColor.color(from: baseFolder, named: "C04")! }
        static var c05: UIColor { UIColor.color(from: baseFolder, named: "C05")! }
        static var c06: UIColor { UIColor.color(from: baseFolder, named: "C06")! }
        static var c07: UIColor { UIColor.color(from: baseFolder, named: "C07")! }
        static var c08: UIColor { UIColor.color(from: baseFolder, named: "C08")! }
        static var c09: UIColor { UIColor.color(from: baseFolder, named: "C09")! }
        static var c10: UIColor { UIColor.color(from: baseFolder, named: "C10")! }
        static var c11: UIColor { UIColor.color(from: baseFolder, named: "C11")! }
        static var c12: UIColor { UIColor.color(from: baseFolder, named: "C12")! }
        static var entertainment: UIColor { UIColor.color(from: baseFolder, named: "Entertainment")! }
        static var general: UIColor { UIColor.color(from: baseFolder, named: "General")! }
        static var services: UIColor { UIColor.color(from: baseFolder, named: "Services")! }
        static var shopping: UIColor { UIColor.color(from: baseFolder, named: "Shopping")! }
    }
    
    static var semanticColors: Theme.SemanticColors {
        .init(primary: Colors.c01,
              selection: Colors.c07,
              disabled: Colors.c05,
              success: Colors.c09,
              warning: Colors.c10,
              error: Colors.c11,
              successBorder: Colors.c09,
              textPrimary: Colors.c01,
              textSecondary: Colors.c03,
              textPlaceholder: Colors.c03,
              backgroundStandard: Colors.c06,
              backgroundHiglighted:  Colors.c02,
              dimmedBackground:  Colors.c01.withAlphaComponent(0.5),
              bottomNavBar:  Colors.c02,
              primaryButton: Colors.c01,
              textPrimaryButton: Colors.c02,
              defaultNavigationBarBackgroundColor: Colors.c02,
              defaultNavigationBarTintColor: Colors.c01,
              transparentNavigationBarTintColor: Colors.c01)
    }
    
    //MARK: Fonts
    
    private enum FontSizes {
        static let title0: CGFloat = 33.0
        static let largeTitle: CGFloat = 28.0
        static let largeTitle2: CGFloat = 23.0
        static let title1: CGFloat = 23.0
        static let title2: CGFloat = 19.0
        static let title3: CGFloat = 16.0
        static let body: CGFloat = 16.0
        static let callout: CGFloat = 16.0
        static let subhead: CGFloat = 14.0
        static let footnote: CGFloat = 12.0
    }
    static func makeSemanticFonts(from fontGenerator: (CGFloat, UIFont.Weight) -> UIFont, fontMetrics: UIFontMetrics = .default) -> Theme.SemanticFonts {
        let titel1 = fontMetrics.scaledFont(for:  fontGenerator(FontSizes.title1, .regular))
        let body = fontMetrics.scaledFont(for:  fontGenerator(FontSizes.body, .regular))
        let caption = fontMetrics.scaledFont(for:  fontGenerator(FontSizes.subhead, .regular))
        let button = fontMetrics.scaledFont(for:  fontGenerator(FontSizes.callout, .regular))
        
        return .init(display: fontMetrics.scaledFont(for:  fontGenerator(FontSizes.title0, .regular)),
                     displayEmphasized: fontMetrics.scaledFont(for:  fontGenerator(FontSizes.title0, .bold)),
                     headline: fontMetrics.scaledFont(for:  fontGenerator(FontSizes.largeTitle, .regular)),
                     headiline2: fontMetrics.scaledFont(for:  fontGenerator(FontSizes.largeTitle2, .regular)),
                     title1: titel1,
                     titleLight: titel1,
                     body: body,
                     bodyEmphasized: fontMetrics.scaledFont(for:  fontGenerator(FontSizes.body, .bold)),
                     button: button,
                     buttonIcon: button,
                     tabBarActive: caption,
                     tabBarInactive: fontMetrics.scaledFont(for:  fontGenerator(FontSizes.subhead, .bold)))
    }
    
}
