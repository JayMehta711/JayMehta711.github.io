//
//  JMPalette.swift
//  ReferenceJourney
//
//  Created by Jay Mehta on 14/06/21.
//

import UIKit

enum  JMPalette: ThemePalette {
    
    
    //MARK: Colors
    
    ///One to One Mapping JM colors contained in Colors.xcassets
    private enum Colors {
        private static let baseFolder = "JM"
        static var amber: UIColor { UIColor.color(from: baseFolder, named: "Amber")!}
        static var color1x1: UIColor { UIColor.color(from: baseFolder, named: "Color1x1")!}
        static var color1x2: UIColor { UIColor.color(from: baseFolder, named: "Color1x2")!}
        static var color1x3: UIColor { UIColor.color(from: baseFolder, named: "Color1x3")!}
        static var color1x4: UIColor { UIColor.color(from: baseFolder, named: "Color1x4")!}
        static var color1x5: UIColor { UIColor.color(from: baseFolder, named: "Color1x5")!}
        static var color1x6: UIColor { UIColor.color(from: baseFolder, named: "Color1x6")!}
        static var color1x7: UIColor { UIColor.color(from: baseFolder, named: "Color1x7")!}
        static var color1x8: UIColor { UIColor.color(from: baseFolder, named: "Color1x8")!}
        static var color1x9: UIColor { UIColor.color(from: baseFolder, named: "Color1x9")!}
        static var color1x10: UIColor { UIColor.color(from: baseFolder, named: "Color1x10")!}
        static var color2x1: UIColor { UIColor.color(from: baseFolder, named: "Color2x1")!}
        static var color2x2: UIColor { UIColor.color(from: baseFolder, named: "Color2x2")!}
        static var color2x3: UIColor { UIColor.color(from: baseFolder, named: "Color2x3")!}
        static var darkAmeber: UIColor { UIColor.color(from: baseFolder, named: "DarkAmeber")!}
        static var darkEmerald: UIColor { UIColor.color(from: baseFolder, named: "DarkEmerald")!}
        static var emerald: UIColor { UIColor.color(from: baseFolder, named: "Emerald")!}
    }
    
    static var semanticColors: Theme.SemanticColors {
        .init(primary: UIColor.dynamicColorWith(defaultColor: Colors.color1x1, darkColor: nil),
              selection: UIColor.dynamicColorWith(defaultColor: Colors.color2x3, darkColor: nil),
              disabled: UIColor.dynamicColorWith(defaultColor: Colors.color1x6, darkColor: Colors.color1x8),
              success: UIColor.dynamicColorWith(defaultColor: Colors.color2x3, darkColor: nil),
              warning: UIColor.dynamicColorWith(defaultColor: Colors.color2x2, darkColor: nil),
              error: UIColor.dynamicColorWith(defaultColor: Colors.color2x1, darkColor: nil),
              successBorder: UIColor.dynamicColorWith(defaultColor: Colors.color1x8, darkColor: nil),
              textPrimary: UIColor.dynamicColorWith(defaultColor: Colors.color1x8, darkColor: Colors.color1x4),
              textSecondary: UIColor.dynamicColorWith(defaultColor: Colors.color1x8, darkColor: Colors.color1x4),
              textPlaceholder: UIColor.dynamicColorWith(defaultColor: Colors.color1x8, darkColor: Colors.color1x4),
              backgroundStandard: UIColor.dynamicColorWith(defaultColor: Colors.color1x4, darkColor: Colors.color1x9),
              backgroundHiglighted: UIColor.dynamicColorWith(defaultColor: Colors.color1x3, darkColor: Colors.color1x9),
              dimmedBackground: UIColor.dynamicColorWith(defaultColor: Colors.color1x2.withAlphaComponent(0.5),
                                                         darkColor: Colors.color1x9.withAlphaComponent(0.5)),
              bottomNavBar: UIColor.dynamicColorWith(defaultColor: Colors.color1x3, darkColor: Colors.color1x9),
              primaryButton: UIColor.dynamicColorWith(defaultColor: Colors.color1x1),
              textPrimaryButton: UIColor.dynamicColorWith(defaultColor: Colors.color1x3),
              defaultNavigationBarBackgroundColor: UIColor.dynamicColorWith(defaultColor: Colors.color1x3, darkColor: Colors.color1x9),
              defaultNavigationBarTintColor: UIColor.dynamicColorWith(defaultColor: Colors.color1x8, darkColor: Colors.color1x4),
              transparentNavigationBarTintColor: UIColor.dynamicColorWith(defaultColor: Colors.color1x8, darkColor: Colors.color1x4))
    }
    
    //MARK: Fonts
    private enum FontSizes {
        static let display: CGFloat = 33.0
        static let headline: CGFloat = 28.0
        static let headline2: CGFloat = 23.0
        static let title1: CGFloat = 23.0
        static let title2: CGFloat = 19.0
        static let body: CGFloat = 16.0
        static let caption: CGFloat = 14.0
        static let footnote: CGFloat = 12.0
    }
    static func makeSemanticFonts(from fontGenerator: (CGFloat, UIFont.Weight) -> UIFont, fontMetrics: UIFontMetrics = .default) -> Theme.SemanticFonts {
        let headline = fontMetrics.scaledFont(for: fontGenerator(FontSizes.headline, .regular))
        let title1 = fontMetrics.scaledFont(for: fontGenerator(FontSizes.title1, .light))
        
        return .init(display: fontMetrics.scaledFont(for: fontGenerator(FontSizes.display, .light)),
                     displayEmphasized: fontMetrics.scaledFont(for: fontGenerator(FontSizes.display, .regular)),
                     headline: headline,
                     headiline2: fontMetrics.scaledFont(for: fontGenerator(FontSizes.headline2, .regular)),
                     title1: title1,
                     titleLight: fontMetrics.scaledFont(for: fontGenerator(FontSizes.title1, .regular)),
                     body: fontMetrics.scaledFont(for: fontGenerator(FontSizes.body, .regular)),
                     bodyEmphasized: fontMetrics.scaledFont(for: fontGenerator(FontSizes.body, .medium)),
                     button: fontMetrics.scaledFont(for: fontGenerator(FontSizes.body, .medium)),
                     buttonIcon: fontMetrics.scaledFont(for: fontGenerator(FontSizes.body, .medium)),
                     tabBarActive: fontMetrics.scaledFont(for: fontGenerator(FontSizes.caption, .regular)),
                     tabBarInactive: fontMetrics.scaledFont(for: fontGenerator(FontSizes.caption, .medium)))
    }
}
