//
//  ThemeReacting.swift
//  ReferenceJourney
//
//  Created by Jay Mehta on 14/06/21.
//

import Foundation
/// Protocols that defines the requirements an objects needs to meet in order to be able to handle Theme changes.
public protocol ThemeReacting: AnyObject {
    ///informs whenever a theme changes, allows for interested parties to react accourdingly
    ///- Parameters theme: New theme beging applied.
    func themeDidChange(_ theme: Theme)
    
}
