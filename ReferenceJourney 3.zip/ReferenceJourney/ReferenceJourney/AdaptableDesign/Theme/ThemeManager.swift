//
//  ThemeManager.swift
//  ReferenceJourney
//
//  Created by Jay Mehta on 14/06/21.
//

import UIKit

public typealias FontGenerator = (_ size: CGFloat , _ weight: UIFont.Weight) -> UIFont

public class ThemeManager {
    //Singleton instance of `ThemeManager` providing access of changing themes, as well as the current one.
    public static let shared = ThemeManager()
    
    //The current `Theme`
    
    public var currentTheme: Theme {
        guard  let theme = _currentTheme else {
            preconditionFailure("""
            `currentTheme` was never initialised!
            please make sure to call `applyThme` before your UI gets initalised.
            """)
        }
        
        return theme
    }
    
    //Private var repsonsible for storing the theme
    //
    //This is required in order to always provide access to a non-optional `Theme` public property.
    
    private var _currentTheme: Theme? {
        didSet{
            if let newTheme = _currentTheme {
                //Sends a message to all componets (or otehr objects) registered as reactors.
                reactorsHashTable.allObjects.forEach { reactor in
                    (reactor as? ThemeReacting)?.themeDidChange(newTheme)
                }
            }
        }
    }
    
    private let reactorsHashTable = NSHashTable<AnyObject>(options:  NSHashTableWeakMemory)
    
    ///Applies a new theme as per provided brand like JM , MS
    ///Calling this method updates the value of `currentTheme`
    /// - Parameters:
    ///     - brand: The brand intented to be themed
    ///     - customFontGenerator: Code block used to generate fonts. if none is provided, uses the default
    ///    `UIFont.systemFont(ofSize:weight:)`
    public func applyTheme(for brand: Theme.Brand, customFontGenerator: FontGenerator?) {
       _currentTheme = makeTheme(branded: brand, customFontGenerator: customFontGenerator)
    }
    
    private func makeTheme(branded brand: Theme.Brand, customFontGenerator: FontGenerator?) -> Theme {
        let fontGenerator = customFontGenerator ?? { UIFont.systemFont(ofSize: $0, weight: $1)}
        
        switch brand {
        case .jm:
            return makeJMTheme(with: fontGenerator)
        case .ms:
            return makeMSTheme(with: fontGenerator)
            
        }
    }
}

//MARK: ThemeReacting

extension ThemeManager {
    /// Subscribes an object to be notified about theme changes.
    /// - Parameter reactor: The object to be subscribed.
    public func addReactor(_ reactor: ThemeReacting) {
        reactorsHashTable.add(reactor)
    }
    
    /// Unsubscribes an object to be notified about theme changes.
    /// - Parameter reactor: The object to be unsubscribed.
    public func removeReactor(_ reactor: ThemeReacting) {
        reactorsHashTable.remove(reactor)
    }
}

private extension ThemeManager {
    func makeJMTheme(with fontGenerator: @escaping FontGenerator) -> Theme {
        let brand = Theme.Brand.jm
        let colors = JMPalette.semanticColors
        
        return Theme.init(brand: brand,
                          colors: colors,
                          fonts: JMPalette.makeSemanticFonts(from: fontGenerator))
        
    }
    
    func makeMSTheme(with fontGenerator: @escaping FontGenerator) -> Theme {
        let brand = Theme.Brand.ms
        let colors = MSPalette.semanticColors
        return Theme.init(brand: brand,
                          colors: colors,
                          fonts: MSPalette.makeSemanticFonts(from: fontGenerator))
    }
}
