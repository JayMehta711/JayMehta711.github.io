//
//  Theme.swift
//  ReferenceJourney
//
//  Created by Jay Mehta on 14/06/21.
//

import UIKit

public class Theme {
    public enum Brand: CaseIterable {
        case jm
        case ms
        
        public var userReadableName: String {
            switch self {
            case .jm:
                 return "JM"
            case .ms:
                 return "MS"
            }
        }
     }
    
    //MARK: Instance properties
    public let brand: Brand
    
    //This colors assigned to individual object and meanings
    public let colors: SemanticColors
    
    //This set of fonts styles for each usage
    public let fonts: SemanticFonts
    
    init(brand: Brand,
         colors: SemanticColors,
         fonts: SemanticFonts
         ) {
        
        self.brand = brand
        self.colors = colors
        self.fonts = fonts
    }
}
