//
//  ReferenceJourneyHomeViewController.swift
//  ReferenceJourney
//
//  Created by Jay Mehta on 08/06/21.
//

import Foundation
import UIKit
final class ReferenceJourneyHomeViewController: UIViewController,ThemeReacting {
    private var presenter: ReferenceJourneyHomePresenterInterface?
    var buttonOnboard: UIButton?
    
    override func viewDidLoad() {
        
        setupNavi()
        setupView()
        ThemeManager.shared.addReactor(self)
    }
    
    func setPresenter(presenter: ReferenceJourneyHomePresenterInterface) {
        self.presenter = presenter
    }
    
    private func setupNavi() {
        title = "Home"
    }
    
    func themeDidChange(_ theme: Theme) {
        self.view.backgroundColor = ThemeManager.shared.currentTheme.colors.backgroundHiglighted
        buttonOnboard?.backgroundColor = ThemeManager.shared.currentTheme.colors.primaryButton
    }
    
    
    private func setupView() {
        view.backgroundColor = ThemeManager.shared.currentTheme.colors.backgroundHiglighted
        let buttonOnBoarding = UIButton()
        view.addSubview(buttonOnBoarding)
        buttonOnBoarding.translatesAutoresizingMaskIntoConstraints = false
        self.buttonOnboard = buttonOnBoarding
        NSLayoutConstraint.activate([
            buttonOnBoarding.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            buttonOnBoarding.heightAnchor.constraint(equalToConstant: 44),
            buttonOnBoarding.topAnchor.constraint(equalTo: view.layoutMarginsGuide.topAnchor, constant: 44),
            buttonOnBoarding.leadingAnchor.constraint(equalTo: view.layoutMarginsGuide.leadingAnchor, constant: 16),
            buttonOnBoarding.trailingAnchor.constraint(equalTo: view.layoutMarginsGuide.trailingAnchor, constant: -16)
        ])
        buttonOnBoarding.setTitle("Show OnboadingScreen", for: .normal)
        buttonOnBoarding.backgroundColor = ThemeManager.shared.currentTheme.colors.primaryButton
        buttonOnBoarding.accessibilityIdentifier = "onboarding-button-home"
        buttonOnBoarding.addTarget(self, action: #selector(buttonAction(sender:)), for: .touchUpInside)
    }

    @objc func buttonAction(sender: UIButton) {
        presenter?.presentOnboardingScreen()
    }
}

extension ReferenceJourneyHomeViewController: ReferenceJourneyHomeViewInterface {
    
}
extension ReferenceJourneyHomeViewController: OnboardingViewDelegate {
    func onboardingViewControllerDidCancel() {
        presenter?.dismissOnboardingScreen()
    }
    
    func onboardingViewControllerDidContinue() {
        
    }
    
    func onboardingViewControllerDidTapURL(_ url: URL, text: String?) {
        
    }
    
    
}
