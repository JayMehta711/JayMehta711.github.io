//
//  ReferenceJourneyHomeInteractor.swift
//  ReferenceJourney
//
//  Created by Jay Mehta on 08/06/21.
//

import Foundation

final class ReferenceJourneyHomeInterector {
    private let configuration: ReferenceJourneyConfiguration
    init(configuration: ReferenceJourneyConfiguration) {
        self.configuration = configuration
    }
}

extension ReferenceJourneyHomeInterector: ReferenceJourneyHomeInterectorInterface {
    
}
