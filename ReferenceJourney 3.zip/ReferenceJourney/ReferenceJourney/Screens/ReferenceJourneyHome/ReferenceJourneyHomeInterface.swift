//
//  ReferenceJourneyHomeInterface.swift
//  ReferenceJourney
//
//  Created by Jay Mehta on 08/06/21.
//

import Foundation

protocol ReferenceJourneyHomePresenterInterface: AnyObject {
    func presentOnboardingScreen()
    func dismissOnboardingScreen()
}

protocol ReferenceJourneyHomeInterectorInterface: AnyObject { }

protocol ReferenceJourneyHomeViewInterface: AnyObject { }
