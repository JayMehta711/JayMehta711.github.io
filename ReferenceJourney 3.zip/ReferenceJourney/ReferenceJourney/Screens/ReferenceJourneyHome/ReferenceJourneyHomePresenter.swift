//
//  ReferenceJourneyHomePresenter.swift
//  ReferenceJourney
//
//  Created by Jay Mehta on 08/06/21.
//

import Foundation
final class ReferenceJourneyHomePresenter {
    private let configuration: ReferenceJourneyConfiguration
    private let router: ReferenceJourneyRouterInterface
    private let interector: ReferenceJourneyHomeInterectorInterface
    private weak var view: ReferenceJourneyHomeViewInterface?
    
    init(configuration: ReferenceJourneyConfiguration,
         router: ReferenceJourneyRouterInterface,
         interector: ReferenceJourneyHomeInterectorInterface,
         view: ReferenceJourneyHomeViewInterface) {
        self.configuration = configuration
        self.router = router
        self.interector = interector
        self.view = view
    }
}

extension ReferenceJourneyHomePresenter: ReferenceJourneyHomePresenterInterface {
    func presentOnboardingScreen() {
        router.navigateToOnBoardingscreen()
    }
    
    func dismissOnboardingScreen() {
        router.popCurrentViewController()
    }
}
