//
//  Bundle.swift
//  ReferenceJourney
//
//  Created by Jay Mehta on 13/06/21.
//

import Foundation

extension Bundle {
    //This bundle for the reference joruney framework
    static let referenceJourney = Bundle(for: ReferenceJourneyConfiguration.self)
}
