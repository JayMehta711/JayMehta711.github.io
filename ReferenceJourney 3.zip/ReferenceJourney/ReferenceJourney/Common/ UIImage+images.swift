//
//   UIImage+images.swift
//  ReferenceJourney
//
//  Created by Jay Mehta on 13/06/21.
//

import Foundation
import UIKit

extension UIImage {
    static let referenceJourneyOnboarding = frameworkImage(named: "onboarding_image_placeholder")
}

private func frameworkImage(named: String) -> UIImage {
    // swiftlint:disable:next force_unwrapping
    return UIImage(named: named, in: .referenceJourney, compatibleWith: nil)!
}
